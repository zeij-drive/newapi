# StarryAPI AstrBot 插件

这个目录是原 `qqbot/` 服务的 AstrBot 插件重写版。把整个
`astrbot_plugin_starryapi` 目录复制到 `AstrBot/data/plugins/`，由 AstrBot
负责 QQ 官方机器人连接、事件验签和消息发送；不再运行 `qqbot/main.go`、PHP
入口或单独的 QQ Bot 守护进程。

## 功能

- `/sapi`：显示帮助菜单。
- `/sapi 邀请码 邮箱`：私聊或群聊获取邀请码，NewAPI 将邀请码邮件发送到该邮箱，QQ 消息不会回显邀请码。
- `/sapi 倍率通知 开启|关闭`：由配置的 QQ 用户在群聊中启停本群倍率变更 @全体通知。
- `/uid`：显示当前 QQ 账号 ID，便于添加到 `ratio_admin_open_ids`。
- `/gptstatus`：无需插件密钥或额外设置，直接读取 OpenAI 状态页并生成状态图片；普通用户每 3 分钟可成功查询一次，AstrBot 管理员和倍率通知管理员不受限制。`auto on/off` 已移除并返回“指令不存在”。
- 直接倍率检测：插件使用已有的 NewAPI 地址和共享密钥定时读取分组倍率，发现手动或自动同步变化后通知已订阅群，不需要额外回调 URL。

若倍率轮询返回 HTTP 404，请确认 `new_api_url` 填的是 NewAPI 根地址，并部署包含 `GET /api/bot/group-ratios` 路由的 NewAPI 构建。插件对 404 仅记录一次提示，避免日志重复刷屏。

## 安装

```text
AstrBot/
└── data/
    └── plugins/
        └── astrbot_plugin_starryapi/
            ├── __init__.py
            ├── main.py
            ├── core.py
            ├── metadata.yaml
            ├── _conf_schema.json
            └── requirements.txt
```

在 AstrBot 管理面板重载插件，或重启 AstrBot。插件依赖 `aiohttp`，AstrBot 通常已经安装；如果没有，插件管理器会按 `requirements.txt` 安装。

AstrBot 中还要先配置 QQ 官方适配器（WebSocket 或 Webhook）。插件不再读取 QQ App ID/App Secret，也不再创建 QQ 平台连接。

## 配置

在插件配置面板填写：

- `new_api_url`：NewAPI 的 HTTPS 根地址，例如 `https://newapi.example.com`；本机开发可以填 `http://127.0.0.1:3000`。
- `starry_api_bot_secret`：与 NewAPI 环境变量 `STARRY_API_BOT_SECRET` 完全一致的随机值，至少 32 个字符。这个值只放在配置中，插件不会写日志或回复消息。
- `ratio_admin_open_ids`：允许执行倍率通知开关的 QQ 用户 ID 列表。
- `ratio_poll_interval`：倍率检测间隔，默认 60 秒，范围 15～86400 秒。插件直接访问 `new_api_url`，不需要开放额外端口或配置回调地址。
- `state_file`：默认 `data/plugin_data/astrbot_plugin_starryapi/state.json`，保存群订阅和倍率基线。

NewAPI 环境变量示例：

```env
STARRY_API_BOT_SECRET=与AstrBot插件完全一致的至少32字符随机值
```

倍率检测请求使用已有共享密钥对 `GET /api/bot/group-ratios` 签名：

```text
GET
/api/bot/group-ratios
{unix_timestamp}
{32位小写nonce}
小写十六进制SHA256(空请求体)
```

用共享密钥计算 HMAC-SHA256。NewAPI 只接受时间戳前后 5 分钟、32 位小写 nonce 和 64 位小写签名，并保存 nonce 防止重放。

## 消息平台说明

插件的消息处理由 AstrBot 完成，因此需要先在 AstrBot 启用 QQ 官方平台并订阅消息事件。倍率通知使用 `At(qq="all")` 发送全体提醒；适配器不支持全体 At 时会自动退化为普通文本消息，不会因单个群发送失败停止其他群。倍率变化由插件直接轮询 NewAPI 检测，无需回调端口或公网 URL。

## 迁移旧服务

停止旧的 Go/PHP QQ Bot 后，再启用这个插件。旧文件保留在仓库的 `qqbot/` 目录中作为兼容参考；运行时只应部署本目录到 AstrBot 插件目录，避免两个服务同时处理同一 QQ 回调。

纯函数测试不需要安装 AstrBot：

```bash
python -m unittest discover -s qqbot/astrbot_plugin_starryapi/tests -p 'test_*.py'
python -m py_compile qqbot/astrbot_plugin_starryapi/core.py qqbot/astrbot_plugin_starryapi/main.py
```
