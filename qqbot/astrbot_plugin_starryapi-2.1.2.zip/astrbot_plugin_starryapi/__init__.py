"""StarryAPI AstrBot plugin package."""
